Config = {}
Config.Framework = 'auto'

Config.PoliceJobs = {['police']=true,['sheriff']=true,['lspd']=true,['bcso']=true,['sasp']=true,['fib']=true,['ranger']=true}
Config.EmsJobs = {['ambulance']=true,['ems']=true}
Config.AdminAce = 'command.admin'

Config.MaskComponentId = 1
Config.MaskMinDrawable = 1
Config.MaskItemNames = {'mask','balaclava','ski_mask','facemask','bandana_mask'}
Config.StrangerPrefix = '陌生人'

Config.Languages = {
    ['en']='英语',['cn']='中文',['es']='西班牙语',['fr']='法语',
    ['de']='德语',['jp']='日语',['kr']='韩语',['ru']='俄语',
    ['it']='意大利语',['pt']='葡萄牙语',['ar']='阿拉伯语',
}

Config.Commands = {
    {type='me',cmd='me',label='/me - 角色动作',color={194,162,218},range=20,bubble=true,bubbleColor={194,162,218},bubbleDur=6,prefix='* {name} ',actionText=true},
    {type='do',cmd='do',label='/do - 环境描述',color={194,162,218},range=20,bubble=true,bubbleColor={194,162,218},bubbleDur=6,prefix='* ',suffix=' (({name}))',actionText=true},
    {type='my',cmd='my',label='/my - 物品描述',color={194,162,218},range=20,bubble=true,bubbleColor={194,162,218},bubbleDur=6,prefix='* {name}\'s ',actionText=true},
    {type='b',cmd='b',label='/b - 本地OOC',color={180,180,180},range=20,bubble=true,bubbleColor={180,180,180},bubbleDur=5,prefix='(( [{id}] {name}: ',suffix=' ))'},
    {type='shout',cmd='s',label='/s - 喊话',color={255,235,130},range=40,bubble=true,bubbleColor={255,235,130},bubbleDur=5,prefix='{name} 喊道: '},
    {type='low',cmd='low',label='/low - 低语',color={200,200,200},range=5,bubble=true,bubbleColor={200,200,200},bubbleDur=4,prefix='{name} 低声说: '},
    {type='megaphone',cmd='m',label='/m - 扩音器',color={255,200,80},range=60,bubble=true,bubbleColor={255,200,80},bubbleDur=6,prefix='[扩音器] {name}: '},
    {type='cw',cmd='cw',label='/cw - 车内聊天',color={200,220,255},range=0,bubble=false,prefix='(车内) {name}: ',special='vehicle'},
    {type='dep',cmd='dep',label='/dep - 部门呼叫',color={100,150,255},range=0,bubble=false,prefix='[部门呼叫] {dept} {name}: ',special='police'},
    {type='radio',cmd='r1',label='/r1 - 无线电1',color={80,180,80},range=0,bubble=false,prefix='[R1] {dept} | {joblabel} {name}: ',special='police'},
    {type='radio',cmd='r2',label='/r2 - 无线电2',color={80,180,80},range=0,bubble=false,prefix='[R2] {dept} | {joblabel} {name}: ',special='police'},
    {type='radio',cmd='r3',label='/r3 - 无线电3',color={80,180,80},range=0,bubble=false,prefix='[R3] {dept} | {joblabel} {name}: ',special='police'},
    {type='radio',cmd='r4',label='/r4 - 无线电4',color={80,180,80},range=0,bubble=false,prefix='[R4] {dept} | {joblabel} {name}: ',special='police'},
    {type='radio',cmd='r5',label='/r5 - 无线电5',color={80,180,80},range=0,bubble=false,prefix='[R5] {dept} | {joblabel} {name}: ',special='police'},
    {type='faction',cmd='f',label='/f - 职业频道',color={120,210,120},range=0,bubble=false,prefix='[职业] {joblabel} {name}: ',special='faction'},
    {type='admin',cmd='a',label='/a - 管理员频道',color={255,80,80},range=0,bubble=false,prefix='[Admin] [{id}] {name}: ',special='admin'},
    {type='tac',cmd='tac',label='/tac - 战术频道',color={255,180,50},range=0,bubble=false,prefix='[TAC] {dept} {joblabel} {name}: ',special='police'},
}

Config.LowTo={color={200,200,200},range=5,prefix='{name} 对 {target} 低声说: ',bubble=true,bubbleColor={200,200,200},bubbleDur=4}
Config.PM={colorSend={255,200,100},colorRecv={255,200,100},prefixSend='(( 私聊发送给 [{tid}] {tname}: ',prefixRecv='(( 私聊来自 [{sid}] {sname}: ',suffix=' ))'}
Config.MeIng={color={194,162,218},bubbleColor={194,162,218},range=20,prefix='* {name} ',interval=8000}
Config.NormalChat={enabled=true,color={255,255,255},range=15,bubble=true,bubbleColor={255,255,255},bubbleDur=5,prefix='{name} 说: '}

Config.BubbleFontId=0; Config.BubbleFontScale=0.28; Config.BubbleMaxWidth=999
Config.BubbleHeadOffset=0.40; Config.BubbleOutline=true; Config.BubbleShadow=true
Config.AutoMeEngine=true; Config.AutoMeWeapon=true
Config.Emergency={policeColor={255,80,80},emsColor={255,150,80},officerDownDelay=5000}
Config.Radio={color={100,200,100},doColor={194,162,218},doRange=15,doDur=5}

Config.WeatherBroadcast = {enabled=true, interval=300}

Config.WeatherData = {
    ['CLEAR']={name='晴天',color={255,220,100},dayTemp='28-32°C',nightTemp='18-22°C',humidity='35%',dayOnly=true,tips={'阳光明媚，请注意防晒和补充水分。','天气晴好，适合户外活动，别忘了戴墨镜哦。','万里无云的好天气，祝您心情愉快！','晴空万里，适合自驾出行，请注意交通安全。'}},
    ['EXTRASUNNY']={name='烈日',color={255,150,50},dayTemp='33-38°C',nightTemp='22-26°C',humidity='25%',dayOnly=true,tips={'高温预警！请尽量避免长时间户外活动，注意防暑降温。','极端高温天气，请多喝水，避免中暑。','烈日炎炎，尽量在阴凉处活动。','今日气温极高，空调可能是您最好的朋友。'}},
    ['CLOUDS']={name='多云',color={180,200,230},dayTemp='22-26°C',nightTemp='16-20°C',humidity='55%',tips={'天气舒适，适合户外活动。','多云天气，温度宜人，是个散步的好日子。','云层较多但不影响出行。','微风和煦，多云间晴，适合外出游玩。'}},
    ['OVERCAST']={name='阴天',color={150,160,180},dayTemp='18-22°C',nightTemp='14-18°C',humidity='65%',tips={'天气阴沉，出行请携带雨具以防万一。','阴云密布，可能随时降雨，建议带伞。','灰蒙蒙的天气，开车请注意开启车灯。','阴天不影响出行，但心情可能需要一杯热咖啡。'}},
    ['RAIN']={name='降雨',color={100,150,220},dayTemp='16-20°C',nightTemp='12-16°C',humidity='80%',tips={'降雨天气，路面湿滑请谨慎驾驶。','雨天出行请携带雨具，注意路面积水。','降雨持续中，开车务必减速慢行。','雨天路滑，行人请走人行道，注意安全。'}},
    ['THUNDER']={name='雷暴',color={180,80,255},dayTemp='14-18°C',nightTemp='10-14°C',humidity='90%',tips={'雷暴天气！请远离空旷地带和高处。','强雷暴来袭，尽快进入室内。','电闪雷鸣，暴雨如注，非必要请勿外出！','极端天气警告！请留在安全的室内环境中。'}},
    ['CLEARING']={name='转晴',color={200,220,150},dayTemp='20-25°C',nightTemp='14-18°C',humidity='50%',tips={'雨后初晴，空气格外清新。','天空渐渐放晴了，出来呼吸新鲜空气吧。','雨过天晴，说不定能看到彩虹哦！','天气正在好转，路面仍可能湿滑。'}},
    ['NEUTRAL']={name='温和',color={180,210,180},dayTemp='22-26°C',nightTemp='16-20°C',humidity='50%',tips={'天气温和，适宜出行。','气温适中，无论做什么都很舒服。','宜人的天气，适合和朋友一起出门走走。'}},
    ['SMOG']={name='雾霾',color={180,170,130},dayTemp='18-22°C',nightTemp='14-18°C',humidity='70%',tips={'能见度较低，驾车请开启雾灯减速慢行。','雾霾天气，建议佩戴口罩出行。','空气质量较差，敏感人群请尽量留在室内。','能见度不佳，行车务必保持安全车距。'}},
    ['FOGGY']={name='大雾',color={160,170,190},dayTemp='14-18°C',nightTemp='10-14°C',humidity='85%',tips={'浓雾预警！能见度极低，非必要请勿驾车。','大雾弥漫，开车请使用雾灯并大幅降低车速。','雾气很重，视线受阻，步行也请注意安全。','浓雾天气，高速公路可能临时封闭。'}},
    ['XMAS']={name='降雪',color={200,220,255},dayTemp='-2-3°C',nightTemp='-6-0°C',humidity='75%',tips={'降雪天气，路面结冰请小心驾驶。','银装素裹的雪景虽美，但出行要格外小心。','大雪纷飞，请穿好棉衣，注意防寒保暖。','下雪天开车请装防滑链，缓慢起步。'}},
    ['SNOWLIGHT']={name='小雪',color={190,210,240},dayTemp='0-4°C',nightTemp='-4-0°C',humidity='70%',tips={'轻微降雪，出行注意防滑保暖。','零星小雪，地面可能开始积雪。','小雪飘飘，温度较低，记得穿厚一点。'}},
    ['BLIZZARD']={name='暴风雪',color={150,180,255},dayTemp='-8--2°C',nightTemp='-12--5°C',humidity='90%',tips={'暴风雪预警！请留在室内，避免一切不必要的出行。','极端暴风雪天气！道路已完全不适合通行。','暴风雪肆虐，能见度接近于零，生命安全第一！','暴风雪警告！请储备好食物和饮用水。'}},
}
