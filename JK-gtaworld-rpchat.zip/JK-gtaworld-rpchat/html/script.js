/*
 * GTA World RP Chat v1.0.0 - NUI
 * Author: JK Team
 */

var RESOURCE_NAME = 'gtaworld-rpchat';
try {
    var thisUrl = window.location.href;
    var match = thisUrl.match(/https:\/\/cfx-nui-([^\/]+)/);
    if (match && match[1]) RESOURCE_NAME = match[1];
} catch(e) {}

function post(endpoint, data) {
    return fetch('https://' + RESOURCE_NAME + '/' + endpoint, {
        method: 'POST',
        body: JSON.stringify(data || {})
    }).catch(function(){});
}

var messagesEl = document.getElementById('chat-messages');
var inputArea = document.getElementById('chat-input-area');
var inputEl = document.getElementById('chat-input');
var settingsBtn = document.getElementById('settings-btn');
var settingsPanel = document.getElementById('settings-panel');
var cmdHint = document.getElementById('cmd-hint');

var BUILTIN_CMDS = [
  {cmd:'/me',desc:'角色动作 (^插入对话)',usage:'/me [描述]'},
  {cmd:'/do',desc:'环境描述',usage:'/do [描述]'},
  {cmd:'/my',desc:'物品描述',usage:'/my [描述]'},
  {cmd:'/meing',desc:'持续动作(循环显示)',usage:'/meing [动作]'},
  {cmd:'/meingoff',desc:'取消持续动作',usage:'/meingoff'},
  {cmd:'/s',desc:'喊话(40m)',usage:'/s [内容]'},
  {cmd:'/low',desc:'低语(5m)',usage:'/low [内容]'},
  {cmd:'/lowto',desc:'对某人低语',usage:'/lowto [ID] [消息]'},
  {cmd:'/m',desc:'扩音器喊话(60m)',usage:'/m [内容]'},
  {cmd:'/language',desc:'用指定语言说话',usage:'/language [语种] [消息]'},
  {cmd:'/cw',desc:'车内聊天(同车可见)',usage:'/cw [消息]'},
  {cmd:'/b',desc:'本地OOC(20m)',usage:'/b [消息]'},
  {cmd:'/pm',desc:'私聊某人',usage:'/pm [ID] [消息]'},
  {cmd:'/f',desc:'职业内部频道',usage:'/f [消息]'},
  {cmd:'/dep',desc:'部门广播(警用)',usage:'/dep [内容]'},
  {cmd:'/tac',desc:'战术频道(警用)',usage:'/tac [消息]'},
  {cmd:'/r1',desc:'警用无线电频道1',usage:'/r1 [消息]'},
  {cmd:'/r2',desc:'警用无线电频道2',usage:'/r2 [消息]'},
  {cmd:'/r3',desc:'警用无线电频道3',usage:'/r3 [消息]'},
  {cmd:'/r4',desc:'警用无线电频道4',usage:'/r4 [消息]'},
  {cmd:'/r5',desc:'警用无线电频道5',usage:'/r5 [消息]'},
  {cmd:'/radio',desc:'对讲机发消息',usage:'/radio [消息]'},
  {cmd:'/radiojoin',desc:'加入对讲机频道',usage:'/radiojoin [1-99]'},
  {cmd:'/radioleave',desc:'离开对讲机频道',usage:'/radioleave'},
  {cmd:'/code1',desc:'Code1 收到/确认呼叫',usage:'/code1'},
  {cmd:'/code2',desc:'Code2 紧急响应(无警报)',usage:'/code2'},
  {cmd:'/code3',desc:'Code3 紧急响应(警灯警笛)',usage:'/code3'},
  {cmd:'/code4',desc:'Code4 现场安全/无需支援',usage:'/code4'},
  {cmd:'/code5',desc:'Code5 便衣蹲守/请避让',usage:'/code5'},
  {cmd:'/code6',desc:'Code6 标记单位远离区域',usage:'/code6'},
  {cmd:'/code7',desc:'Code7 用餐时间',usage:'/code7'},
  {cmd:'/code33',desc:'Code33 无线电静默(紧急)',usage:'/code33'},
  {cmd:'/code99',desc:'Code99 紧急求援(全员支援)',usage:'/code99'},
  {cmd:'/911p',desc:'市民报警(警察可见)',usage:'/911p [内容]'},
  {cmd:'/ems',desc:'呼叫急救(EMS可见)',usage:'/ems [描述]'},
  {cmd:'/p',desc:'导航至邮编',usage:'/p [邮编号]'},
  {cmd:'/job',desc:'查看职业信息',usage:'/job'},
  {cmd:'/name',desc:'查看姓名/社安号/电话',usage:'/name'},
  {cmd:'/cash',desc:'查看现金',usage:'/cash'},
  {cmd:'/bank',desc:'查看银行余额',usage:'/bank'},
  {cmd:'/a',desc:'管理员频道',usage:'/a [消息]'},
  {cmd:'/clear',desc:'清理自己的聊天屏幕',usage:'/clear'},
  {cmd:'/chatdebug',desc:'调试信息',usage:'/chatdebug'},
];

var externalCmds = [], extLoaded = false;
function loadExt() {
    if (extLoaded) return;
    post('getAllCommands').then(function(r) { return r.json(); }).then(function(list) {
        if (!Array.isArray(list)) return;
        var bs = new Set(BUILTIN_CMDS.map(function(c) { return c.cmd.replace('/', ''); }));
        list.forEach(function(n) { if (n && n.length > 0 && !bs.has(n) && n[0] !== '+' && n[0] !== '-') externalCmds.push({cmd: '/' + n, desc: '(其他插件)', usage: '/' + n}); });
        extLoaded = true;
    }).catch(function() {});
}

var settings = {fontSize: 13, lineHeight: 15, maxMsg: 50, fadeTime: 30, mode: 'always', timestamp: 'on'};
function loadS() { try { var s = localStorage.getItem('gw_rpc_v1'); if (s) Object.assign(settings, JSON.parse(s)); } catch (e) {} syncUI(); }
function saveS() { try { localStorage.setItem('gw_rpc_v1', JSON.stringify(settings)); } catch (e) {} }
function syncUI() { document.getElementById('set-fontsize').value = settings.fontSize; document.getElementById('val-fontsize').textContent = settings.fontSize; document.getElementById('set-lineheight').value = settings.lineHeight; document.getElementById('val-lineheight').textContent = (settings.lineHeight / 10).toFixed(2); document.getElementById('set-maxmsg').value = settings.maxMsg; document.getElementById('val-maxmsg').textContent = settings.maxMsg; document.getElementById('set-fadetime').value = settings.fadeTime; document.getElementById('val-fadetime').textContent = settings.fadeTime + 's'; document.getElementById('set-mode').value = settings.mode; document.getElementById('set-timestamp').value = settings.timestamp; applyS(); }
function applyS() { document.querySelectorAll('.chat-msg').forEach(function(el) { el.style.fontSize = settings.fontSize + 'px'; el.style.lineHeight = (settings.lineHeight / 10).toFixed(2); el.style.padding = settings.mode === 'compact' ? '0 6px' : '1px 6px'; }); document.querySelectorAll('.chat-ts').forEach(function(el) { el.style.display = settings.timestamp === 'on' ? 'inline' : 'none'; }); }
['set-fontsize', 'set-lineheight', 'set-maxmsg', 'set-fadetime'].forEach(function(id) { document.getElementById(id).addEventListener('input', function() { var m = {'set-fontsize': 'fontSize', 'set-lineheight': 'lineHeight', 'set-maxmsg': 'maxMsg', 'set-fadetime': 'fadeTime'}; settings[m[id]] = parseInt(this.value); saveS(); syncUI(); trimMsg(); }); });
document.getElementById('set-mode').addEventListener('change', function() { settings.mode = this.value; saveS(); if (settings.mode === 'always') { messagesEl.style.opacity = '1'; clearF(); } else startF(); });
document.getElementById('set-timestamp').addEventListener('change', function() { settings.timestamp = this.value; saveS(); applyS(); });
settingsBtn.addEventListener('click', function() { settingsPanel.style.display = settingsPanel.style.display === 'block' ? 'none' : 'block'; });
loadS();

var hist = [], hIdx = -1;
function pushH(t) { if (!t) return; if (hist.length > 0 && hist[hist.length - 1] === t) return; hist.push(t); if (hist.length > 50) hist.shift(); hIdx = hist.length; }

var fadeT = null, inputActive = false;
function pad2(n) { return n < 10 ? '0' + n : '' + n; }
function getTS() { var d = new Date(); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()); }
function showM() { messagesEl.style.opacity = '1'; clearF(); if (settings.mode !== 'always' && !inputActive) startF(); }
function clearF() { if (fadeT) { clearTimeout(fadeT); fadeT = null; } }
function startF() { if (settings.mode === 'always' || inputActive) return; fadeT = setTimeout(function() { messagesEl.style.transition = 'opacity 1s ease'; messagesEl.style.opacity = '0'; }, settings.fadeTime * 1000); }
function trimMsg() { while (messagesEl.children.length > settings.maxMsg) messagesEl.removeChild(messagesEl.firstChild); }

function renderTextWithSpeech(p, text) { if (text.indexOf('^') === -1) { var sp = document.createElement('span'); sp.textContent = text; p.appendChild(sp); return; } var parts = text.split('^'); for (var i = 0; i < parts.length; i++) { if (parts[i] === '') continue; var sp = document.createElement('span'); sp.textContent = parts[i]; if (i % 2 === 1) sp.style.color = '#ffffff'; p.appendChild(sp); } }

function addMessage(text, color, cmd) { var el = document.createElement('div'); el.className = 'chat-msg'; el.setAttribute('data-cmd', cmd || 'say'); var ts = document.createElement('span'); ts.className = 'chat-ts'; ts.textContent = '[' + getTS() + '] '; if (settings.timestamp !== 'on') ts.style.display = 'none'; el.appendChild(ts); if (color && Array.isArray(color)) el.style.color = 'rgb(' + color[0] + ',' + color[1] + ',' + color[2] + ')'; renderTextWithSpeech(el, text); el.style.fontSize = settings.fontSize + 'px'; el.style.lineHeight = (settings.lineHeight / 10).toFixed(2); if (settings.mode === 'compact') el.style.padding = '0 6px'; messagesEl.appendChild(el); trimMsg(); messagesEl.scrollTop = messagesEl.scrollHeight; showM(); }

function clearMessages() { messagesEl.innerHTML = ''; }

function updateHint(val) { if (!val || val.length < 1 || val[0] !== '/') { cmdHint.style.display = 'none'; return; } loadExt(); var q = val.toLowerCase(); var all = BUILTIN_CMDS.concat(externalCmds); var keyword = q.replace('/', ''); var ms = all.filter(function(c) { return c.cmd.toLowerCase().startsWith(q) || (keyword.length >= 2 && c.desc && c.desc.toLowerCase().indexOf(keyword) !== -1); }); if (ms.length === 0) { cmdHint.style.display = 'none'; return; } var seen = {}, unique = []; ms.forEach(function(c) { if (!seen[c.cmd]) { seen[c.cmd] = true; unique.push(c); } }); cmdHint.innerHTML = ''; unique.slice(0, 25).forEach(function(c) { var item = document.createElement('div'); item.className = 'cmd-hint-item'; item.innerHTML = '<span class="cmd-hint-cmd">' + c.cmd + '</span>' + (c.desc || '') + (c.usage ? '<span style="float:right;color:#555;font-size:11px">' + c.usage + '</span>' : ''); item.addEventListener('mousedown', function(e) { e.preventDefault(); inputEl.value = c.cmd + ' '; cmdHint.style.display = 'none'; inputEl.focus(); }); cmdHint.appendChild(item); }); cmdHint.style.display = 'block'; }

function openInput() {
    inputActive = true;
    inputArea.classList.add('active');
    messagesEl.style.opacity = '1';
    clearF();
    post('typingState', {typing: true});
    setTimeout(function() { inputEl.value = ''; inputEl.focus(); }, 50);
}

function closeInput() {
    inputActive = false;
    inputArea.classList.remove('active');
    settingsPanel.style.display = 'none';
    cmdHint.style.display = 'none';
    inputEl.value = '';
    inputEl.blur();
    hIdx = hist.length;
    post('typingState', {typing: false});
    post('closeInput');
    if (settings.mode !== 'always') startF();
}

function sendInput() {
    var text = inputEl.value.trim();
    pushH(text);
    inputArea.classList.remove('active');
    settingsPanel.style.display = 'none';
    cmdHint.style.display = 'none';
    inputEl.value = '';
    inputEl.blur();
    inputActive = false;
    hIdx = hist.length;
    post('typingState', {typing: false});
    post('sendMessage', {text: text});
    if (settings.mode !== 'always') startF();
}

inputEl.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); sendInput(); }
    else if (e.key === 'Escape') { e.preventDefault(); closeInput(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (hist.length > 0) { if (hIdx > 0) hIdx--; inputEl.value = hist[hIdx] || ''; } }
    else if (e.key === 'ArrowDown') { e.preventDefault(); if (hIdx < hist.length - 1) { hIdx++; inputEl.value = hist[hIdx] || ''; } else { hIdx = hist.length; inputEl.value = ''; } }
    else if (e.key === 'Tab') { e.preventDefault(); var all = BUILTIN_CMDS.concat(externalCmds); var q = inputEl.value.toLowerCase(); var ms = all.filter(function(c) { return c.cmd.toLowerCase().startsWith(q); }); if (ms.length > 0) { inputEl.value = ms[0].cmd + ' '; cmdHint.style.display = 'none'; updateHint(inputEl.value); } }
});
inputEl.addEventListener('input', function() { updateHint(inputEl.value); });
document.addEventListener('keydown', function(e) { if (inputActive) e.stopPropagation(); });

window.addEventListener('message', function(event) {
    var d = event.data;
    if (!d || !d.action) return;
    switch (d.action) {
        case 'addMessage': addMessage(d.text, d.color, d.cmd); break;
        case 'openInput': openInput(); break;
        case 'closeInput': closeInput(); break;
        case 'clearMessages': clearMessages(); break;
    }
});

if (settings.mode === 'always') messagesEl.style.opacity = '1'; else startF();
