--[[
    GTA World RP Chat v1.0.0 - Client
    Author: JK Team
]]

local DEBUG = false
local function DebugLog(msg) if DEBUG then print('[GW-RPChat DEBUG] ' .. tostring(msg)) end end

local activeBubbles = {}
local meingActive, meingText = false, ''
local chatOpen = false
local typingBubble = false
local typingPlayers = {}
local lastEngineState, lastWeaponHash, officerDownTriggered = false, 0, false
local isMasked = false
local lastClientWeather, lastWeatherBroadcast = '', 0
local lastTypingState = false -- ★ 防止重复发送typing事件
local chatCooldown = 0 -- ★ 打开冷却时间

local FONT_ID = Config.BubbleFontId or 0
local FONT_SC = Config.BubbleFontScale or 0.28
local HEAD_OFF = Config.BubbleHeadOffset or 0.40
local OUTLINE = Config.BubbleOutline ~= false
local SHADOW = Config.BubbleShadow ~= false

local function GetHeadCoords(ped) local h = GetPedBoneCoords(ped, 12844, 0, 0, 0); return h.x, h.y, h.z + HEAD_OFF end
local function GetScale(d) if d < 1 then d = 1 end; local f = (1 / GetGameplayCamFov()) * 100; local s = (FONT_SC / d) * 2 * f; if s > FONT_SC * 1.5 then s = FONT_SC * 1.5 end; if s < 0.12 then s = 0.12 end; return s end
local function Draw3D(x, y, z, t, sc, r, g, b, a, yo) SetDrawOrigin(x, y, z, 0); SetTextFont(FONT_ID); SetTextScale(0, sc); SetTextColour(r, g, b, a); SetTextCentre(true); if OUTLINE then SetTextOutline() end; if SHADOW then SetTextDropshadow(0, 0, 0, 0, math.floor(a * 0.7)); SetTextDropShadow() end; BeginTextCommandDisplayText('STRING'); AddTextComponentSubstringPlayerName(t); EndTextCommandDisplayText(0, yo or 0); ClearDrawOrigin() end
local function FindPed(sid) for _, p in pairs(GetActivePlayers()) do if GetPlayerServerId(p) == sid then local ped = GetPlayerPed(p); if ped ~= 0 and DoesEntityExist(ped) then return ped end end end; return nil end
local function GetStreetAndPostal() local co = GetEntityCoords(PlayerPedId()); local sh, ch = GetStreetNameAtCoord(co.x, co.y, co.z); local street = GetStreetNameFromHashKey(sh) or '未知'; if ch and ch ~= 0 then local c = GetStreetNameFromHashKey(ch); if c and c ~= '' then street = street .. ' / ' .. c end end; local postal = '未知'; if GetResourceState('nearest-postal') == 'started' then local ok, p = pcall(exports['nearest-postal'].getPostal); if ok and p then postal = tostring(p) end end; return street, postal end

local weaponFallback = {[0xA2719263]='手枪',[0x1B06D571]='手枪',[0xBFE256D4]='冲锋枪',[0x83BF0278]='冲锋枪',[0xEFE7E2DF]='泵动式霰弹枪',[0x0C472FE2]='战斗手枪',[0xD205520E]='微型冲锋枪',[0xBFD21232]='突击步枪',[0x394F415C]='手枪',[0x99B507EA]='刀',[0xDFE37640]='球棒',[0x678B81B1]='小刀',[0x4E875F73]='步枪',[0xAF113F99]='重型手枪',[0xA284510B]='突击步枪',[0x624FE830]='战斗MG',[0x9D61E50F]='消音手枪',[0x63AB0442]='重型狙击枪',[0xC0A3098D]='战斗霰弹枪',[0x7846A318]='电击枪',[0x2BE6766B]='狙击步枪',[0x1D073A89]='火箭筒',[0x7FD62962]='手枪MK2'}
local function GetWeaponName(weaponHash)
    if GetResourceState('ox_inventory') == 'started' then
        local ok, items = pcall(exports['ox_inventory'].Search, 'slots', nil)
        if ok and items then for _, slot in pairs(items) do if slot and slot.name then if (slot.metadata and slot.metadata.hash == weaponHash) or GetHashKey(string.upper(slot.name)) == weaponHash then return slot.label or slot.name end end end end
        local ok2, allItems = pcall(exports['ox_inventory'].Items)
        if ok2 and allItems then for itemName, itemData in pairs(allItems) do if itemData.hash == weaponHash or GetHashKey(string.upper(itemName)) == weaponHash then return itemData.label or itemName end end end
    end
    if GetResourceState('qs-inventory') == 'started' then local ok, label = pcall(exports['qs-inventory'].GetItemLabel, weaponHash); if ok and label and label ~= '' then return label end end
    return weaponFallback[weaponHash] or '武器'
end

local validCodes = {code1=true,code2=true,code3=true,code4=true,code5=true,code6=true,code7=true,code33=true,code99=true}
local weatherHashToName = {[GetHashKey('CLEAR')]='CLEAR',[GetHashKey('EXTRASUNNY')]='EXTRASUNNY',[GetHashKey('CLOUDS')]='CLOUDS',[GetHashKey('OVERCAST')]='OVERCAST',[GetHashKey('RAIN')]='RAIN',[GetHashKey('THUNDER')]='THUNDER',[GetHashKey('CLEARING')]='CLEARING',[GetHashKey('NEUTRAL')]='NEUTRAL',[GetHashKey('SMOG')]='SMOG',[GetHashKey('FOGGY')]='FOGGY',[GetHashKey('XMAS')]='XMAS',[GetHashKey('SNOWLIGHT')]='SNOWLIGHT',[GetHashKey('BLIZZARD')]='BLIZZARD'}
local function GetCurrentWeatherName() local h = GetPrevWeatherTypeHashName(); if h and weatherHashToName[h] then return weatherHashToName[h] end; h = GetNextWeatherTypeHashName(); if h and weatherHashToName[h] then return weatherHashToName[h] end; return nil end

-- ★ typing事件: 只在状态变化时发送, 不重复发
local function SetTyping(state)
    if state ~= lastTypingState then
        lastTypingState = state
        TriggerServerEvent('gw-rpchat:typing', state)
    end
end

-- 屏蔽原版聊天
AddEventHandler('chatMessage', function() CancelEvent() end)
Citizen.CreateThread(function() while true do DisableControlAction(0, 245, true); Citizen.Wait(0) end end)

-- 面具
Citizen.CreateThread(function() while true do Citizen.Wait(2000); local ped = PlayerPedId(); local masked = false; local dr = GetPedDrawableVariation(ped, Config.MaskComponentId or 1); if dr and dr >= (Config.MaskMinDrawable or 1) then masked = true end
    if not masked then for _, iN in ipairs(Config.MaskItemNames or {}) do if GetResourceState('ox_inventory') == 'started' then local ok, c = pcall(exports['ox_inventory'].Search, 'count', iN); if ok and c and c > 0 then local pi = GetPedPropIndex(ped, 0); if pi and pi >= 0 then masked = true end end elseif GetResourceState('qs-inventory') == 'started' then local ok, r = pcall(exports['qs-inventory'].hasItem, iN); if ok and r then masked = true end end end end
    if masked ~= isMasked then isMasked = masked; TriggerServerEvent('gw-rpchat:maskState', isMasked) end end end)

-- ★ 打开聊天 (加冷却防止闪烁)
local function OpenChatInput()
    local now = GetGameTimer()
    if now - chatCooldown < 500 then return end -- 500ms冷却
    chatOpen = true
    chatCooldown = now
    SetNuiFocus(true, true)
    SendNUIMessage({action = 'openInput'})
    SetTyping(true)
    DebugLog('聊天打开')
end

local function CloseChatInput()
    if not chatOpen then return end -- 防止重复关闭
    chatOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({action = 'closeInput'})
    SetTyping(false)
    DebugLog('聊天关闭')
end

local function ProcessMessage(text)
    if not text or text == '' then return end
    DebugLog('处理: ' .. text)
    if text:sub(1, 1) == '/' then
        local parts = {}; for w in text:gmatch('%S+') do parts[#parts + 1] = w end
        local cmd = parts[1]:sub(2):lower(); local rest = table.concat(parts, ' ', 2)
        if cmd == 'clear' then SendNUIMessage({action='clearMessages'}); SendNUIMessage({action='addMessage',text='[系统] 屏幕已清理',color={180,180,180},cmd='system'}); return end
        if cmd == 'lowto' and #parts >= 3 then local tid = tonumber(parts[2]); local msg = table.concat(parts, ' ', 3); if tid and msg ~= '' then TriggerServerEvent('gw-rpchat:lowto', tid, msg) end; return end
        if cmd == 'pm' and #parts >= 3 then local tid = tonumber(parts[2]); local msg = table.concat(parts, ' ', 3); if tid and msg ~= '' then TriggerServerEvent('gw-rpchat:pm', tid, msg) end; return end
        if cmd == 'meing' and rest ~= '' then TriggerServerEvent('gw-rpchat:meing', rest, false); return end
        if cmd == 'meingoff' then TriggerServerEvent('gw-rpchat:meingoff'); return end
        if cmd == 'job' or cmd == 'name' or cmd == 'cash' or cmd == 'bank' then TriggerServerEvent('gw-rpchat:queryInfo', cmd); return end
        if cmd == '911p' and rest ~= '' then local s, p = GetStreetAndPostal(); TriggerServerEvent('gw-rpchat:911p', rest, s, p); return end
        if cmd == 'ems' and rest ~= '' then local s, p = GetStreetAndPostal(); TriggerServerEvent('gw-rpchat:emsCall', rest, s, p); return end
        if cmd == 'p' and parts[2] then
            local pN = parts[2]
            if GetResourceState('nearest-postal') == 'started' then
                ExecuteCommand('postal ' .. pN)
                SendNUIMessage({action='addMessage', text='[系统] 正在导航至邮编 ' .. pN, color={100,255,100}, cmd='system'})
            else
                SendNUIMessage({action='addMessage', text='[系统] nearest-postal 未安装', color={255,100,100}, cmd='system'})
            end
            return
        end
        if cmd == 'radiojoin' and parts[2] then TriggerServerEvent('gw-rpchat:radiojoin', tonumber(parts[2])); return end
        if cmd == 'radioleave' then TriggerServerEvent('gw-rpchat:radioleave'); return end
        if cmd == 'radio' and rest ~= '' then TriggerServerEvent('gw-rpchat:radioMsg', rest); return end
        if cmd == 'language' and #parts >= 3 then TriggerServerEvent('gw-rpchat:language', parts[2]:lower(), table.concat(parts, ' ', 3)); return end
        if validCodes[cmd] then local s, p = GetStreetAndPostal(); TriggerServerEvent('gw-rpchat:policeCode', cmd, s, p); return end
        for _, v in ipairs(Config.Commands) do if v.cmd == cmd then if rest ~= '' then TriggerServerEvent('gw-rpchat:send', v.type, v.cmd, rest) end; return end end
        ExecuteCommand(text:sub(2)); return
    end
    if Config.NormalChat.enabled then TriggerServerEvent('gw-rpchat:normal', text) end
end

-- NUI 回调
RegisterNUICallback('sendMessage', function(data, cb)
    DebugLog('NUI sendMessage')
    CloseChatInput()
    ProcessMessage(data.text or '')
    cb('ok')
end)

RegisterNUICallback('closeInput', function(_, cb)
    DebugLog('NUI closeInput')
    CloseChatInput()
    cb('ok')
end)

RegisterNUICallback('typingState', function(d, cb) cb('ok') end) -- typing由Lua控制,不依赖NUI
RegisterNUICallback('settingsChanged', function(_, cb) cb('ok') end)
RegisterNUICallback('getAllCommands', function(_, cb) local cmds = GetRegisteredCommands(); local list = {}; for _, c in ipairs(cmds) do list[#list + 1] = c.name end; cb(list) end)

-- ★ T键: +openchat 和 -openchat 都注册, 防止FiveM报错
RegisterCommand('+openchat', function()
    if not chatOpen then OpenChatInput() end
end, false)
RegisterCommand('-openchat', function() end, false) -- 空函数,防止key release报错
RegisterKeyMapping('+openchat', 'Open Chat', 'keyboard', 'T')

-- 接收
RegisterNetEvent('gw-rpchat:receive')
AddEventHandler('gw-rpchat:receive', function(p) if not p then return end; SendNUIMessage({action='addMessage',text=p.fullText,color=p.color or {255,255,255},cmd=p.cmd or 'say'}); if p.bubble and p.src then local ped = FindPed(p.src); if ped then local bc = p.bubbleColor or {255,255,255}; activeBubbles[#activeBubbles+1] = {ped=ped,text=p.fullText,r=bc[1],g=bc[2],b=bc[3],expire=GetGameTimer()+(p.bubbleDur or 5)*1000} end end end)
RegisterNetEvent('gw-rpchat:bubbleOnly')
AddEventHandler('gw-rpchat:bubbleOnly', function(d) if not d then return end; local ped = FindPed(d.src); if ped then activeBubbles[#activeBubbles+1] = {ped=ped,text=d.text,r=d.r,g=d.g,b=d.b,expire=GetGameTimer()+(d.dur or 8)*1000} end end)
RegisterNetEvent('gw-rpchat:notify')
AddEventHandler('gw-rpchat:notify', function(msg) SendNUIMessage({action='addMessage',text='[系统] '..msg,color={255,100,100},cmd='system'}) end)
RegisterNetEvent('gw-rpchat:setWaypoint')
AddEventHandler('gw-rpchat:setWaypoint', function(x, y) SetNewWaypoint(x, y) end)

-- /meing
RegisterNetEvent('gw-rpchat:meingStart')
AddEventHandler('gw-rpchat:meingStart', function(msg) meingActive = true; meingText = msg end)
RegisterNetEvent('gw-rpchat:meingStop')
AddEventHandler('gw-rpchat:meingStop', function() meingActive = false; meingText = ''; SendNUIMessage({action='addMessage',text='[系统] 持续动作已取消',color={180,180,180},cmd='system'}) end)
Citizen.CreateThread(function() while true do if meingActive and meingText ~= '' then TriggerServerEvent('gw-rpchat:meing', meingText, true) end; Citizen.Wait(Config.MeIng.interval or 8000) end end)

RegisterNetEvent('gw-rpchat:typingSync')
AddEventHandler('gw-rpchat:typingSync', function(s, v) if v then typingPlayers[s] = true else typingPlayers[s] = nil end end)

Citizen.CreateThread(function()
    while true do
        local myId = GetPlayerServerId(PlayerId())
        if chatOpen then
            typingPlayers[myId] = true
        else
            typingPlayers[myId] = nil
        end
        Citizen.Wait(500)
    end
end)

Citizen.CreateThread(function() while true do local hasAny = false; for _ in pairs(typingPlayers) do hasAny = true; break end; if hasAny then local mx, my, mz = table.unpack(GetEntityCoords(PlayerPedId())); for sid, _ in pairs(typingPlayers) do local ped = FindPed(sid); if ped and DoesEntityExist(ped) then local hx, hy, hz = GetHeadCoords(ped); local d = Vdist(mx, my, mz, hx, hy, hz); if d <= 25 and d > 0 and IsSphereVisible(hx, hy, hz, 0.5) then Draw3D(hx, hy, hz + 0.25, '[...]', GetScale(d) * 0.9, 255, 255, 255, 180, 0.0) end end end; Citizen.Wait(0) else Citizen.Wait(200) end end end)

-- 气泡
Citizen.CreateThread(function() while true do local now = GetGameTimer(); local nb = {}; for i = 1, #activeBubbles do if activeBubbles[i].expire > now then nb[#nb+1] = activeBubbles[i] end end; activeBubbles = nb; if #activeBubbles > 0 then local mx, my, mz = table.unpack(GetEntityCoords(PlayerPedId())); for i = 1, #activeBubbles do local b = activeBubbles[i]; if b.ped and DoesEntityExist(b.ped) then local hx, hy, hz = GetHeadCoords(b.ped); local d = Vdist(mx, my, mz, hx, hy, hz); if d <= 30 and d > 0 and IsSphereVisible(hx, hy, hz, 0.5) then local sc = GetScale(d); local l = b.expire - now; local a = l < 1000 and math.max(0, math.floor(l/1000*255)) or 255; Draw3D(hx, hy, hz + 0.15, b.text, sc, b.r, b.g, b.b, a, 0.0) end end end; Citizen.Wait(0) else Citizen.Wait(100) end end end)

-- 自动/me: 引擎
if Config.AutoMeEngine then Citizen.CreateThread(function() while true do Citizen.Wait(1000); local ped = PlayerPedId(); local veh = GetVehiclePedIsIn(ped, false); if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then local e = GetIsVehicleEngineRunning(veh); if e and not lastEngineState then TriggerServerEvent('gw-rpchat:autoMe', '启动了车辆引擎') elseif not e and lastEngineState then TriggerServerEvent('gw-rpchat:autoMe', '关闭了车辆引擎') end; lastEngineState = e else lastEngineState = false end end end) end

-- 自动/me: 武器
if Config.AutoMeWeapon then Citizen.CreateThread(function() while true do Citizen.Wait(1000); local ped = PlayerPedId(); local _, cur = GetCurrentPedWeapon(ped); local un = GetHashKey('WEAPON_UNARMED'); if cur ~= un and lastWeaponHash == un then TriggerServerEvent('gw-rpchat:autoMe', '拿出了 ' .. GetWeaponName(cur)) elseif cur == un and lastWeaponHash ~= un and lastWeaponHash ~= 0 then TriggerServerEvent('gw-rpchat:autoMe', '收起了 ' .. GetWeaponName(lastWeaponHash)) end; lastWeaponHash = cur end end) end

-- 警员倒地
Citizen.CreateThread(function() while true do Citizen.Wait(2000); local ped = PlayerPedId(); local hp = GetEntityHealth(ped); if hp <= 100 and not officerDownTriggered then local s, p = GetStreetAndPostal(); officerDownTriggered = true; Citizen.Wait(Config.Emergency.officerDownDelay or 5000); TriggerServerEvent('gw-rpchat:officerDown', s, p) elseif hp > 100 then officerDownTriggered = false end end end)

-- 天气
if Config.WeatherBroadcast and Config.WeatherBroadcast.enabled then Citizen.CreateThread(function() Citizen.Wait(15000); lastClientWeather = GetCurrentWeatherName() or ''; lastWeatherBroadcast = GetGameTimer(); while true do Citizen.Wait(60000); local now = GetGameTimer(); local cw = GetCurrentWeatherName(); if cw then local changed = (cw ~= lastClientWeather and lastClientWeather ~= ''); local hourly = (now - lastWeatherBroadcast) >= 3600000; if changed or hourly then TriggerServerEvent('gw-rpchat:weatherReport', cw, changed and '天气变化' or '定时播报', GetClockHours()); lastWeatherBroadcast = now end; lastClientWeather = cw end end end) end

-- 调试
RegisterCommand('chatdebug', function() local tc = 0; for _ in pairs(typingPlayers) do tc = tc + 1 end; local msg = string.format('chatOpen=%s | typing=%d | bubbles=%d | meing=%s | masked=%s | cooldown=%d', tostring(chatOpen), tc, #activeBubbles, tostring(meingActive), tostring(isMasked), chatCooldown); print('[GW-RPChat] ' .. msg); SendNUIMessage({action='addMessage', text='[调试] '..msg, color={255,255,0}, cmd='system'}) end, false)

DebugLog('Client v1.0.0 loaded by JK Team')
