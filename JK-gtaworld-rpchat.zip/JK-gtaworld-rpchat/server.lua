--[[
    GTA World RP Chat v1.0.0 - Server
    Author: JK Team
]]

local FrameworkType, ESXObject, QBCoreObject = nil, nil, nil
local radioChannels, strangerIds, maskedPlayers = {}, {}, {}
local lastBroadcastedWeather = ''
local RESOURCE = GetCurrentResourceName()

-- ============================================================
-- 启动自检系统
-- ============================================================
local function SelfCheck()
    local errors, warnings, passed = {}, {}, 0
    print('')
    print('^3╔══════════════════════════════════════════════════╗')
    print('^3║       GTA World RP Chat v1.0.0 - JK Team       ║')
    print('^3║              启动自检系统                        ║')
    print('^3╚══════════════════════════════════════════════════╝^7')
    print('')

    -- 检查1: 框架
    local fwFound = false
    if GetResourceState('qbx_core') == 'started' then fwFound = true; passed = passed + 1; print('^2[✓] 框架检测: QBox (qbx_core)^7')
    elseif GetResourceState('qb-core') == 'started' then fwFound = true; passed = passed + 1; print('^2[✓] 框架检测: QBCore^7')
    elseif GetResourceState('es_extended') == 'started' then fwFound = true; passed = passed + 1; print('^2[✓] 框架检测: ESX^7')
    else warnings[#warnings+1] = '未检测到框架, 将使用Standalone模式'; print('^3[!] 框架检测: 未找到, Standalone模式^7') end

    -- 检查2: NUI文件
    local nuiOk = true
    local nuiFiles = {'html/index.html', 'html/style.css', 'html/script.js'}
    for _, f in ipairs(nuiFiles) do
        local path = GetResourcePath(RESOURCE) .. '/' .. f
        local file = io.open(path, 'r')
        if file then file:close() else nuiOk = false; errors[#errors+1] = '缺少文件: ' .. f end
    end
    if nuiOk then passed = passed + 1; print('^2[✓] NUI文件: index.html / style.css / script.js 完整^7')
    else print('^1[✗] NUI文件: 缺少文件!^7') end

    -- 检查3: config.lua
    if Config and Config.Commands and #Config.Commands > 0 then
        passed = passed + 1; print('^2[✓] 配置文件: ' .. #Config.Commands .. ' 个命令已注册^7')
    else errors[#errors+1] = 'Config.Commands 为空或未加载'; print('^1[✗] 配置文件: Commands 未加载^7') end

    -- 检查4: nearest-postal
    if GetResourceState('nearest-postal') == 'started' then
        passed = passed + 1; print('^2[✓] 邮编系统: nearest-postal 已启动^7')
    else warnings[#warnings+1] = 'nearest-postal 未启动, /p /911p 邮编功能不可用'; print('^3[!] 邮编系统: nearest-postal 未启动^7') end

    -- 检查5: 背包系统
    local invName = 'none'
    if GetResourceState('ox_inventory') == 'started' then invName = 'ox_inventory'
    elseif GetResourceState('qs-inventory') == 'started' then invName = 'qs-inventory' end
    if invName ~= 'none' then passed = passed + 1; print('^2[✓] 背包系统: ' .. invName .. '^7')
    else warnings[#warnings+1] = '未检测到背包系统, 武器名将使用内置映射'; print('^3[!] 背包系统: 未检测到 ox/qs^7') end

    -- 检查6: chat 资源
    if GetResourceState('chat') == 'started' then
        warnings[#warnings+1] = 'FiveM默认chat资源仍在运行, 建议关闭 (注释掉 ensure chat)'
        print('^3[!] 默认聊天: chat资源仍在运行, 建议关闭^7')
    else passed = passed + 1; print('^2[✓] 默认聊天: chat资源已关闭^7') end

    -- 检查7: 天气系统
    local weatherSys = 'none'
    if GetResourceState('qb-weathersync') == 'started' then weatherSys = 'qb-weathersync'
    elseif GetResourceState('vSync') == 'started' then weatherSys = 'vSync'
    elseif GetResourceState('cd_easytime') == 'started' then weatherSys = 'cd_easytime' end
    if weatherSys ~= 'none' then print('^2[✓] 天气系统: ' .. weatherSys .. ' (播报使用GTA Native)^7')
    else print('^3[!] 天气系统: 未检测到天气插件, 播报使用GTA原生天气^7') end
    passed = passed + 1

    -- 检查8: 警察/EMS职业配置
    local policeCount, emsCount = 0, 0
    for _ in pairs(Config.PoliceJobs or {}) do policeCount = policeCount + 1 end
    for _ in pairs(Config.EmsJobs or {}) do emsCount = emsCount + 1 end
    passed = passed + 1
    print('^2[✓] 职业配置: ' .. policeCount .. ' 个警察职业, ' .. emsCount .. ' 个EMS职业^7')

    -- 检查9: 天气数据
    local weatherCount = 0
    for _ in pairs(Config.WeatherData or {}) do weatherCount = weatherCount + 1 end
    passed = passed + 1
    print('^2[✓] 天气数据: ' .. weatherCount .. ' 种天气配置^7')

    -- 检查10: 资源名
    passed = passed + 1
    print('^2[✓] 资源名称: ' .. RESOURCE .. '^7')

    -- 结果
    print('')
    if #errors > 0 then
        print('^1══════════ 错误 (' .. #errors .. ') ══════════^7')
        for _, e in ipairs(errors) do print('^1  ✗ ' .. e .. '^7') end
    end
    if #warnings > 0 then
        print('^3══════════ 警告 (' .. #warnings .. ') ══════════^7')
        for _, w in ipairs(warnings) do print('^3  ! ' .. w .. '^7') end
    end
    print('')
    if #errors == 0 then
        print('^2╔══════════════════════════════════════════════════╗')
        print('^2║  自检通过! ' .. passed .. '/10 项通过, ' .. #warnings .. ' 个警告           ║')
        print('^2║  GTA World RP Chat v1.0.0 已就绪                ║')
        print('^2╚══════════════════════════════════════════════════╝^7')
    else
        print('^1╔══════════════════════════════════════════════════╗')
        print('^1║  自检失败! ' .. #errors .. ' 个错误需要修复                  ║')
        print('^1╚══════════════════════════════════════════════════╝^7')
    end
    print('')
end

-- ============================================================
-- 框架检测
-- ============================================================
Citizen.CreateThread(function()
    Citizen.Wait(500)
    local m = Config.Framework or 'auto'
    if m == 'qbox' or (m == 'auto' and GetResourceState('qbx_core') == 'started') then
        FrameworkType = 'qbox'
    elseif m == 'qbcore' or (m == 'auto' and GetResourceState('qb-core') == 'started') then
        FrameworkType = 'qbcore'; QBCoreObject = exports['qb-core']:GetCoreObject()
    elseif m == 'esx' or (m == 'auto' and GetResourceState('es_extended') == 'started') then
        FrameworkType = 'esx'; TriggerEvent('esx:getSharedObject', function(o) ESXObject = o end)
        if not ESXObject then ESXObject = exports['es_extended']:getSharedObject() end
    else FrameworkType = 'standalone' end

    -- 启动自检
    SelfCheck()
end)

-- ============================================================
-- 角色信息函数 (与v2.9完全一致)
-- ============================================================
function GetCharName(src) src=tonumber(src); if not src or src<=0 then return 'Unknown' end
    if FrameworkType=='qbox' then local ok,p=pcall(exports['qbx_core'].GetPlayer,exports['qbx_core'],src); if ok and p and p.PlayerData and p.PlayerData.charinfo then local c=p.PlayerData.charinfo; local n=((c.firstname or '')..' '..(c.lastname or '')):match('^%s*(.-)%s*$'); if n~='' then return n end end
    elseif FrameworkType=='qbcore' and QBCoreObject then local ok,p=pcall(QBCoreObject.Functions.GetPlayer,src); if ok and p and p.PlayerData and p.PlayerData.charinfo then local c=p.PlayerData.charinfo; local n=((c.firstname or '')..' '..(c.lastname or '')):match('^%s*(.-)%s*$'); if n~='' then return n end end
    elseif FrameworkType=='esx' and ESXObject then local ok,xp=pcall(ESXObject.GetPlayerFromId,src); if ok and xp and xp.getName then local ok2,n=pcall(xp.getName); if ok2 and n and n~='' then return n end end end
    return GetPlayerName(src) or ('Player '..src) end

function GetJobInfo(src) src=tonumber(src); if not src then return 'none','未知','未知' end
    if FrameworkType=='qbox' then local ok,p=pcall(exports['qbx_core'].GetPlayer,exports['qbx_core'],src); if ok and p and p.PlayerData and p.PlayerData.job then local j=p.PlayerData.job; return j.name or 'none',j.label or '未知',(j.grade and j.grade.name) or '未知' end
    elseif FrameworkType=='qbcore' and QBCoreObject then local ok,p=pcall(QBCoreObject.Functions.GetPlayer,src); if ok and p and p.PlayerData and p.PlayerData.job then local j=p.PlayerData.job; return j.name or 'none',j.label or '未知',(j.grade and j.grade.name) or '未知' end
    elseif FrameworkType=='esx' and ESXObject then local ok,xp=pcall(ESXObject.GetPlayerFromId,src); if ok and xp and xp.job then return xp.job.name or 'none',xp.job.label or '未知',xp.job.grade_label or '未知' end end
    return 'none','未知','未知' end

function GetMoney(src) src=tonumber(src); if not src then return 0,0 end
    if FrameworkType=='qbox' then local ok,p=pcall(exports['qbx_core'].GetPlayer,exports['qbx_core'],src); if ok and p and p.PlayerData and p.PlayerData.money then return p.PlayerData.money.cash or 0,p.PlayerData.money.bank or 0 end
    elseif FrameworkType=='qbcore' and QBCoreObject then local ok,p=pcall(QBCoreObject.Functions.GetPlayer,src); if ok and p and p.PlayerData and p.PlayerData.money then return p.PlayerData.money.cash or 0,p.PlayerData.money.bank or 0 end
    elseif FrameworkType=='esx' and ESXObject then local ok,xp=pcall(ESXObject.GetPlayerFromId,src); if ok and xp then return (xp.getMoney and xp.getMoney()) or 0,(xp.getAccount and xp.getAccount('bank') and xp.getAccount('bank').money) or 0 end end; return 0,0 end

function GetIdentityInfo(src) src=tonumber(src); if not src then return '未知','未知' end; local cid,phone='未知','未知'
    if FrameworkType=='qbox' then local ok,p=pcall(exports['qbx_core'].GetPlayer,exports['qbx_core'],src); if ok and p and p.PlayerData then cid=p.PlayerData.citizenid or '未知'; if p.PlayerData.charinfo then phone=tostring(p.PlayerData.charinfo.phone or '未知') end end
    elseif FrameworkType=='qbcore' and QBCoreObject then local ok,p=pcall(QBCoreObject.Functions.GetPlayer,src); if ok and p and p.PlayerData then cid=p.PlayerData.citizenid or '未知'; if p.PlayerData.charinfo then phone=tostring(p.PlayerData.charinfo.phone or '未知') end end
    elseif FrameworkType=='esx' and ESXObject then local ok,xp=pcall(ESXObject.GetPlayerFromId,src); if ok and xp then cid=xp.identifier or '未知' end end; return cid,phone end

function IsPolice(src) return Config.PoliceJobs[GetJobInfo(src)]==true end
function IsEms(src) return Config.EmsJobs[GetJobInfo(src)]==true end
function IsAdmin(src) if IsPlayerAceAllowed(tostring(src),Config.AdminAce or 'command.admin') then return true end
    if FrameworkType=='qbcore' and QBCoreObject then local ok,r=pcall(QBCoreObject.Functions.HasPermission,src,'admin'); if ok and r then return true end end
    if FrameworkType=='esx' and ESXObject then local ok,xp=pcall(ESXObject.GetPlayerFromId,src); if ok and xp then local g=xp.getGroup and xp.getGroup() or ''; if g=='admin' or g=='superadmin' then return true end end end; return false end
function FormatMsg(t,v) for k,val in pairs(v) do t=string.gsub(t,'{'..k..'}',tostring(val)) end; return t end
function GetStrangerId(src) if not strangerIds[src] then strangerIds[src]=math.random(1000,9999) end; return strangerIds[src] end
function GetDisplayName(src) if maskedPlayers[src] then return Config.StrangerPrefix..GetStrangerId(src) end; return GetCharName(src) end

AddEventHandler('playerDropped',function() local src=source; radioChannels[src]=nil; strangerIds[src]=nil; maskedPlayers[src]=nil end)
RegisterNetEvent('gw-rpchat:maskState')
AddEventHandler('gw-rpchat:maskState',function(m) maskedPlayers[source]=m end)

-- ============================================================
-- 所有消息事件 (与v2.9完全一致, 此处省略注释节省篇幅)
-- ============================================================
RegisterNetEvent('gw-rpchat:typing')
AddEventHandler('gw-rpchat:typing',function(b) local src=source; local co=GetEntityCoords(GetPlayerPed(src)); for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and t~=src and #(co-GetEntityCoords(GetPlayerPed(t)))<=25 then TriggerClientEvent('gw-rpchat:typingSync',t,src,b) end end end)

RegisterNetEvent('gw-rpchat:send')
AddEventHandler('gw-rpchat:send',function(ct,cn,msg) local src=source; local name=GetDisplayName(src); local co=GetEntityCoords(GetPlayerPed(src)); local jn,jl,gl=GetJobInfo(src); local cfg=nil; for _,v in ipairs(Config.Commands) do if v.cmd==cn then cfg=v;break end end; if not cfg then return end; local vars={name=name,id=src,job=jn,joblabel=gl,dept=jl}; local ft=FormatMsg(cfg.prefix or '',vars)..msg..FormatMsg(cfg.suffix or '',vars); local pl={src=src,name=name,cmd=cn,type=ct,message=msg,fullText=ft,color=cfg.color,bubble=cfg.bubble,bubbleColor=cfg.bubbleColor,bubbleDur=cfg.bubbleDur or 5,sx=co.x,sy=co.y,sz=co.z}; local sp=cfg.special
    if not sp and cfg.range>0 then for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(co-GetEntityCoords(GetPlayerPed(t)))<=cfg.range then TriggerClientEvent('gw-rpchat:receive',t,pl) end end
    elseif not sp and cfg.range==-1 then TriggerClientEvent('gw-rpchat:receive',-1,pl)
    elseif sp=='police' then if not IsPolice(src) then TriggerClientEvent('gw-rpchat:notify',src,'你不是警察');return end; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and IsPolice(t) then TriggerClientEvent('gw-rpchat:receive',t,pl) end end
    elseif sp=='faction' then for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and GetJobInfo(t)==jn then TriggerClientEvent('gw-rpchat:receive',t,pl) end end
    elseif sp=='vehicle' then local myV=GetVehiclePedIsIn(GetPlayerPed(src),false); if myV==0 then TriggerClientEvent('gw-rpchat:notify',src,'你不在车内');return end; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and GetVehiclePedIsIn(GetPlayerPed(t),false)==myV then TriggerClientEvent('gw-rpchat:receive',t,pl) end end
    elseif sp=='admin' then if not IsAdmin(src) then TriggerClientEvent('gw-rpchat:notify',src,'你不是管理员');return end; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and IsAdmin(t) then TriggerClientEvent('gw-rpchat:receive',t,pl) end end end end)

RegisterNetEvent('gw-rpchat:language')
AddEventHandler('gw-rpchat:language',function(lc,msg) local src=source; local name=GetDisplayName(src); local co=GetEntityCoords(GetPlayerPed(src)); local ln=Config.Languages[lc] or lc; local ft=name..' 用'..ln..'说: '..msg; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(co-GetEntityCoords(GetPlayerPed(t)))<=15 then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='say',fullText=ft,color={255,255,255},bubble=true,bubbleColor={255,255,255},bubbleDur=5,sx=co.x,sy=co.y,sz=co.z}) end end end)
RegisterNetEvent('gw-rpchat:lowto')
AddEventHandler('gw-rpchat:lowto',function(tid,msg) local src=source; local sN,tN=GetDisplayName(src),GetDisplayName(tid); local sc=GetEntityCoords(GetPlayerPed(src)); local cfg=Config.LowTo; local ft=FormatMsg(cfg.prefix,{name=sN,id=src,target=tN,tid=tid})..msg; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(sc-GetEntityCoords(GetPlayerPed(t)))<=cfg.range then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='lowto',fullText=ft,color=cfg.color,bubble=cfg.bubble,bubbleColor=cfg.bubbleColor,bubbleDur=cfg.bubbleDur or 4,sx=sc.x,sy=sc.y,sz=sc.z}) end end end)
RegisterNetEvent('gw-rpchat:pm')
AddEventHandler('gw-rpchat:pm',function(tid,msg) local src=source; local sN,tN=GetCharName(src),GetCharName(tid); local cfg=Config.PM; if not GetPlayerPed(tid) or GetPlayerPed(tid)==0 then TriggerClientEvent('gw-rpchat:notify',src,'玩家不在线');return end; local sv={sid=src,sname=sN,tid=tid,tname=tN}; TriggerClientEvent('gw-rpchat:receive',src,{src=src,cmd='pm',bubble=false,fullText=FormatMsg(cfg.prefixSend,sv)..msg..FormatMsg(cfg.suffix,sv),color=cfg.colorSend}); TriggerClientEvent('gw-rpchat:receive',tid,{src=src,cmd='pm',bubble=false,fullText=FormatMsg(cfg.prefixRecv,sv)..msg..FormatMsg(cfg.suffix,sv),color=cfg.colorRecv}) end)
RegisterNetEvent('gw-rpchat:meing')
AddEventHandler('gw-rpchat:meing',function(msg,isR) local src=source; local name=GetDisplayName(src); local cfg=Config.MeIng; local ft=FormatMsg(cfg.prefix,{name=name,id=src})..msg; local co=GetEntityCoords(GetPlayerPed(src)); for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(co-GetEntityCoords(GetPlayerPed(t)))<=cfg.range then if isR then TriggerClientEvent('gw-rpchat:bubbleOnly',t,{src=src,text=ft,r=cfg.bubbleColor[1],g=cfg.bubbleColor[2],b=cfg.bubbleColor[3],dur=cfg.interval/1000}) else TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='meing',fullText=ft,color=cfg.color,bubble=true,bubbleColor=cfg.bubbleColor,bubbleDur=cfg.interval/1000,sx=co.x,sy=co.y,sz=co.z}) end end end; if not isR then TriggerClientEvent('gw-rpchat:meingStart',src,msg,ft) end end)
RegisterNetEvent('gw-rpchat:meingoff')
AddEventHandler('gw-rpchat:meingoff',function() TriggerClientEvent('gw-rpchat:meingStop',source) end)
RegisterNetEvent('gw-rpchat:normal')
AddEventHandler('gw-rpchat:normal',function(msg) local src=source; local name=GetDisplayName(src); local cfg=Config.NormalChat; local co=GetEntityCoords(GetPlayerPed(src)); local ft=FormatMsg(cfg.prefix,{name=name,id=src})..msg; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(co-GetEntityCoords(GetPlayerPed(t)))<=cfg.range then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='say',fullText=ft,color=cfg.color,bubble=cfg.bubble,bubbleColor=cfg.bubbleColor,bubbleDur=cfg.bubbleDur or 5,sx=co.x,sy=co.y,sz=co.z}) end end end)
RegisterNetEvent('gw-rpchat:autoMe')
AddEventHandler('gw-rpchat:autoMe',function(msg) local src=source; local name=GetDisplayName(src); local co=GetEntityCoords(GetPlayerPed(src)); local ft='* '..name..' '..msg; for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and #(co-GetEntityCoords(GetPlayerPed(t)))<=20 then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='me',fullText=ft,color={194,162,218},bubble=true,bubbleColor={194,162,218},bubbleDur=4,sx=co.x,sy=co.y,sz=co.z}) end end end)
RegisterNetEvent('gw-rpchat:queryInfo')
AddEventHandler('gw-rpchat:queryInfo',function(q) local src=source; local name=GetCharName(src); local jn,jl,gl=GetJobInfo(src); local cash,bank=GetMoney(src); local t=''
    if q=='job' then t='[信息] 职业: '..jl..' | 职位: '..gl
    elseif q=='name' then local cid,phone=GetIdentityInfo(src); t='[信息] 姓名: '..name..' (ID: '..src..') | 社安号: '..cid..' | 电话: '..phone
    elseif q=='cash' then t='[信息] 现金: $'..tostring(cash)
    elseif q=='bank' then t='[信息] 银行余额: $'..tostring(bank) end
    if t~='' then TriggerClientEvent('gw-rpchat:receive',src,{src=src,cmd='info',fullText=t,color={100,200,255},bubble=false}) end end)

RegisterNetEvent('gw-rpchat:911p')
AddEventHandler('gw-rpchat:911p',function(msg,st,po) local src=source; local co=GetEntityCoords(GetPlayerPed(src)); local t='[911 报警] 位置: '..st..' (邮编: '..po..') | '..msg; for _,pid in pairs(GetPlayers()) do local tt=tonumber(pid); if tt and IsPolice(tt) then TriggerClientEvent('gw-rpchat:receive',tt,{src=src,cmd='dep',fullText=t,color=Config.Emergency.policeColor,bubble=false}); TriggerClientEvent('gw-rpchat:setWaypoint',tt,co.x,co.y) end end; TriggerClientEvent('gw-rpchat:receive',src,{src=src,cmd='system',fullText='[系统] 报警已发送',color={100,255,100},bubble=false}) end)
RegisterNetEvent('gw-rpchat:emsCall')
AddEventHandler('gw-rpchat:emsCall',function(msg,st,po) local src=source; local co=GetEntityCoords(GetPlayerPed(src)); local t='[EMS 呼叫] 位置: '..st..' (邮编: '..po..') | '..msg; for _,pid in pairs(GetPlayers()) do local tt=tonumber(pid); if tt and IsEms(tt) then TriggerClientEvent('gw-rpchat:receive',tt,{src=src,cmd='dep',fullText=t,color=Config.Emergency.emsColor,bubble=false}); TriggerClientEvent('gw-rpchat:setWaypoint',tt,co.x,co.y) end end; TriggerClientEvent('gw-rpchat:receive',src,{src=src,cmd='system',fullText='[系统] 急救呼叫已发送',color={100,255,100},bubble=false}) end)
RegisterNetEvent('gw-rpchat:officerDown')
AddEventHandler('gw-rpchat:officerDown',function(st,po) local src=source; if not IsPolice(src) then return end; local name=GetCharName(src); local _,dept,grade=GetJobInfo(src); local co=GetEntityCoords(GetPlayerPed(src)); local t='[紧急] 警员倒地! '..dept..' '..grade..' '..name..' | 位置: '..st..' (邮编: '..po..')'; for _,pid in pairs(GetPlayers()) do local tt=tonumber(pid); if tt and IsPolice(tt) then TriggerClientEvent('gw-rpchat:receive',tt,{src=src,cmd='dep',fullText=t,color={255,50,50},bubble=false}); TriggerClientEvent('gw-rpchat:setWaypoint',tt,co.x,co.y) end end end)

local CODE_DEFS={code1={text='Code 1 - 确认收到呼叫, 常规响应',color={80,180,80}},code2={text='Code 2 - 紧急响应, 无警灯警笛前往',color={255,200,80}},code3={text='Code 3 - 紧急响应, 开启警灯警笛!',color={255,150,50}},code4={text='Code 4 - 现场安全, 无需进一步支援',color={80,180,80}},code5={text='Code 5 - 执行便衣蹲守, 请各单位注意避让',color={80,180,80}},code6={text='Code 6 - 标记单位请远离该区域',color={80,180,80}},code7={text='Code 7 - 用餐时间',color={80,180,80}},code33={text='Code 33 - 无线电紧急静默!',color={255,80,80}},code99={text='Code 99 - 紧急求援! 请求所有单位支援!',color={255,50,50},waypoint=true}}
RegisterNetEvent('gw-rpchat:policeCode')
AddEventHandler('gw-rpchat:policeCode',function(code,st,po) local src=source; if not IsPolice(src) then TriggerClientEvent('gw-rpchat:notify',src,'你不是警察');return end; local def=CODE_DEFS[code]; if not def then TriggerClientEvent('gw-rpchat:notify',src,'未知Code');return end; local name=GetCharName(src); local _,dept,grade=GetJobInfo(src); local co=GetEntityCoords(GetPlayerPed(src)); local pfx=(code=='code99' or code=='code33') and '[紧急 R1] ' or '[R1] '; local text=pfx..dept..' '..grade..' '..name..' 在 '..st..' (邮编: '..po..') '..def.text
    for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and IsPolice(t) then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='r1',fullText=text,color=def.color,bubble=false}); if def.waypoint then TriggerClientEvent('gw-rpchat:setWaypoint',t,co.x,co.y) end end end end)

RegisterNetEvent('gw-rpchat:radiojoin')
AddEventHandler('gw-rpchat:radiojoin',function(ch) local src=source; ch=tonumber(ch); if not ch or ch<1 or ch>99 then TriggerClientEvent('gw-rpchat:notify',src,'频道范围: 1-99');return end; radioChannels[src]=ch; TriggerClientEvent('gw-rpchat:receive',src,{src=src,cmd='system',fullText='[系统] 已加入对讲机频道 '..ch,color={100,200,100},bubble=false}) end)
RegisterNetEvent('gw-rpchat:radioleave')
AddEventHandler('gw-rpchat:radioleave',function() radioChannels[source]=nil; TriggerClientEvent('gw-rpchat:receive',source,{src=source,cmd='system',fullText='[系统] 已离开对讲机频道',color={200,200,100},bubble=false}) end)
RegisterNetEvent('gw-rpchat:radioMsg')
AddEventHandler('gw-rpchat:radioMsg',function(msg) local src=source; local ch=radioChannels[src]; if not ch then TriggerClientEvent('gw-rpchat:notify',src,'你没有加入对讲机频道');return end; local name=GetDisplayName(src); local co=GetEntityCoords(GetPlayerPed(src)); local rt='[对讲机 CH'..ch..'] '..name..': '..msg; local dt='* 可以听见对讲机传来: '..msg..' (('..name..'))'
    for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and radioChannels[t]==ch then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='radio',fullText=rt,color=Config.Radio.color,bubble=false}) end end
    for _,pid in pairs(GetPlayers()) do local t=tonumber(pid); if t and radioChannels[t]~=ch then local tc=GetEntityCoords(GetPlayerPed(t)); if #(co-tc)<=Config.Radio.doRange then TriggerClientEvent('gw-rpchat:receive',t,{src=src,cmd='do',fullText=dt,color={194,162,218},bubble=true,bubbleColor={194,162,218},bubbleDur=Config.Radio.doDur,sx=co.x,sy=co.y,sz=co.z}) end end end end)

RegisterNetEvent('gw-rpchat:weatherReport')
AddEventHandler('gw-rpchat:weatherReport',function(weather,reason,gameHour)
    if not Config.WeatherBroadcast or not Config.WeatherBroadcast.enabled then return end
    weather=(weather or ''):upper()
    if reason=='天气变化' and weather==lastBroadcastedWeather then return end
    local data=Config.WeatherData[weather]; if not data then return end
    gameHour=tonumber(gameHour) or 12; local isNight=(gameHour>=20 or gameHour<6)
    if data.dayOnly and isNight then return end
    local temp=isNight and (data.nightTemp or data.dayTemp) or (data.dayTemp or data.nightTemp or '未知')
    local tip='注意安全。'; if data.tips and #data.tips>0 then tip=data.tips[math.random(1,#data.tips)] end
    local timeDesc=isNight and '夜间' or '日间'; local duration=math.random(1,3)..'-'..math.random(4,8)..' 小时'
    local prefix=reason=='定时播报' and '当前天气' or '天气变化'
    local text='[气象台] '..prefix..': '..data.name..' | '..timeDesc..' 气温: '..temp..' | 湿度: '..data.humidity..' | 预计持续: '..duration..' | '..tip
    TriggerClientEvent('gw-rpchat:receive',-1,{src=0,cmd='weather',fullText=text,color=data.color or {150,200,255},bubble=false})
    lastBroadcastedWeather=weather
end)
