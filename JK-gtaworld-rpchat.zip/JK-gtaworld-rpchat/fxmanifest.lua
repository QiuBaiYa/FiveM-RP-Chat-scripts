fx_version 'cerulean'
game 'gta5'

author 'JK Team'
description 'GTA World Style RP Chat System'
version '1.0.0'

shared_scripts {
    'config.lua'
}

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
